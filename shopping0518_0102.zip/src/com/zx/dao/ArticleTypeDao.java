package com.zx.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.zx.bean.ArticleType;
import com.zx.util.ConnectionFactory;
import com.zx.util.pager.PageModel;

public class ArticleTypeDao {

	

	public List<ArticleType> getAllFType() {
		
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的一级类型 只要第一级 即四位的
			String sql = "select * from ec_article_type where length(code) = 4";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			
			//进行查询
			rs = pstm.executeQuery();
			
			//创建Article集合用于封装数据
			List<ArticleType> articleTypes = new ArrayList<>();
			//遍历
			while(rs.next()) {
				//封装商品类型信息
				ArticleType articleType = new ArticleType();
				articleType.setCode(rs.getString("code"));
				articleType.setName(rs.getString("name"));
				//将商品的信息存放在集合中
				articleTypes.add(articleType);
			}
			//将上面弄到的商品信息返回
			return articleTypes;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		return null;
	}

	/**
	 * @param string
	 * @return
	 * 根据一级商品类型获取对应的二级商品类型	传入的是一级商品类型+"%"
	 * 查询语句为
	 * SELECT * FROM ec_article_type WHERE CODE LIKE '0001%' AND LENGTH(CODE)=8;
	 */
	public List<ArticleType> getSecondTypesByCode(String code) {
		// TODO Auto-generated method stub
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的一级类型 只要第一级 即四位的
			String sql = "SELECT * FROM ec_article_type WHERE CODE LIKE ? AND LENGTH(CODE)=8";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			//这里的setString函数也许就是用来将上面的sql语句中的?替换成传入的变量code的吧
			pstm.setString(1, code);
			
			//进行查询
			rs = pstm.executeQuery();
			
			//创建Article集合用于封装数据
			List<ArticleType> articleTypes = new ArrayList<>();
			//遍历
			while(rs.next()) {
				//封装商品类型信息
				ArticleType articleType = new ArticleType();
				articleType.setCode(rs.getString("code"));
				articleType.setName(rs.getString("name"));
				//将商品的信息存放在集合中
				articleTypes.add(articleType);
			}
			//将上面弄到的商品信息返回
			return articleTypes;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		return null;
	}

	/**
	 * @return
	 * 
	 */
	public List<ArticleType> getAllTypes(PageModel pageModel) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的一级类型 只要第一级 即四位的
			//delFlag = '0'代表状态正常 未被逻辑删除
			String sql = "SELECT * FROM ec_article_type where delFlag = '0' limit ?,?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			//这里的setString函数也许就是用来将上面的sql语句中的?替换成传入的变量code的吧
			pstm.setInt(1, pageModel.getStartNum());
			pstm.setInt(2, pageModel.getPageSize());
			
			//进行查询
			rs = pstm.executeQuery();
			
			//创建Article集合用于封装数据
			List<ArticleType> articleTypes = new ArrayList<>();
			//遍历
			while(rs.next()) {
				//封装商品类型信息
				ArticleType articleType = new ArticleType();
				articleType.setCode(rs.getString("code"));
				articleType.setName(rs.getString("name"));
				articleType.setRemark(rs.getString("remark"));
				//将商品的信息存放在集合中
				articleTypes.add(articleType);
			}
			//将上面弄到的商品信息返回
			return articleTypes;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		return null;
	}

	/**
	 * @return
	 * 获取商品类型的总记录数
	 */
	public int getTotalNum() {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		//while(resultset.next())组合
		
		try {
			//1.获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//2.定义sql语句	查所有的商品
			String sql = "select count(*) from ec_article_type where delFlag = '0'";
			//3.准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			
			//4.进行查询
			//查询的时候不用传入sql参数  有参数时pstm自己知道语句是什么  没有?不需要传入参数时可以传入sql
			rs = pstm.executeQuery();

			
			if(rs.next()) {
				return rs.getInt(1);	// get查询结构的第一个参数(count)就好
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		return 0;
	}

	/**
	 * @return
	 * 获取最大的一级商品类型
	 */
	public String findMaxFcode() {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		//while(resultset.next())组合
		
		try {
			//1.获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//2.定义sql语句	查所有的商品
			String sql = "select max(code) from ec_article_type where length(code) = 4";
			//3.准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			
			//4.进行查询
			//查询的时候不用传入sql参数  有参数时pstm自己知道语句是什么  没有?不需要传入参数时可以传入sql
			rs = pstm.executeQuery();

			
			if(rs.next()) {
				return rs.getString(1);	// 应该是"0015"这样的一个字符串
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		return "";
		// 没找到便返回空字符串
	}

	/**
	 * @param parentCode
	 * @return
	 */
	public String findMaxScode(String parentCode) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		//while(resultset.next())组合
		
		try {
			//1.获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//2.定义sql语句	查所有的商品
			String sql = "select max(code) from ec_article_type where code like ? and length(code) = 8";
			//3.准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, parentCode+"%");
			
			//4.进行查询
			//查询的时候不用传入sql参数  有参数时pstm自己知道语句是什么  没有?不需要传入参数时可以传入sql
			rs = pstm.executeQuery();

			
			if(rs.next()) {
				return rs.getString(1);	// 应该是"00010017"这样的一个字符串
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		return "";
		// 没找到便返回空字符串
	}

	/**
	 * @param type
	 * 保存商品类型
	 */
	public void saveType(ArticleType type) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的一级类型 只要第一级 即四位的
			String sql = "insert into ec_article_type(code,name,remark) values(?,?,?)";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			//这里的setString函数也许就是用来将上面的sql语句中的?替换成传入的变量code的吧
			pstm.setString(1, type.getCode());
			pstm.setString(2, type.getName());
			pstm.setString(3, type.getRemark());
			
			//进行数据插入
			pstm.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
	}

	/**
	 * @param code
	 * @return
	 * 根据商品类型的code获取商品类型
	 */
	public ArticleType getArticleType(String code) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的一级类型 只要第一级 即四位的
			String sql = "select * from ec_article_type where code = ?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, code);
			
			//进行查询
			rs = pstm.executeQuery();

			if(rs.next()) {
				ArticleType type = new ArticleType();
				type.setCode(code);
				type.setName(rs.getString("name"));
				type.setRemark(rs.getString("remark"));
				return  type;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		return null;
	}

	/**
	 * @param name
	 * @param remark
	 * @param code
	 * 更新商品的name和remark
	 */
	public void updateType(String name, String remark, String code) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的一级类型 只要第一级 即四位的
			String sql = "update ec_article_type set name = ? , remark = ? where code = ?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, name);
			pstm.setString(2, remark);
			pstm.setString(3, code);
			
			// 进行更新
			pstm.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
	}

	/**
	 * @param type		应修改成的样子
	 * @param oldCode	修改之前的code
	 * @param name
	 * @param remark
	 * 1.将当前的商品类型挂在用户选择的上级类型下 进行添加操作
	 * 2.之前关联到该商品类型的商品类型code需要发生变化
	 * 3.删除之前的商品类型
	 */
	public void updateTypeWithUpperType(ArticleType type, String oldCode, String name, String remark) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			// 设置提交方式为手动提交
			con.setAutoCommit(false);
			
			//准备需要发送的sql语句 
			// 1.将当前的商品类型挂在用户选择的上级类型下 进行添加操作
			String insertSql = "insert into ec_article_type(code,name,remark) values(?,?,?)";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(insertSql);
			pstm.setString(1, type.getCode());
			pstm.setString(2, name);
			pstm.setString(3, remark);
			// 加入一份pstm
			pstm.addBatch();
			
			// 2.之前关联到该商品类型的商品类型code需要发生变化
			String updateSql = "update ec_article set article_code = ? where article_code = ?";
			pstm = con.prepareStatement(updateSql);
			pstm.setString(1, type.getCode());
			pstm.setString(2, oldCode);
			pstm.addBatch();
			
			// 3.删除之前的商品类型
			String deleteSql = "delete from ec_article_type where code = ?";
			pstm = con.prepareStatement(deleteSql);
			pstm.setString(1, oldCode);
			pstm.addBatch();
			
			// 执行批处理
			pstm.executeBatch();
			// 提交事务
			con.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
	}

	/**
	 * @param code
	 * @return
	 */
	public boolean findArticleByCode(String code) {
		Connection con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的一级类型 只要第一级 即四位的
			// disabled = '0'表示商品在上架状态
			String sql = "select * from ec_article where type_code = ? and disabled = '0'";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, code);
			
			// 进行查询
			rs = pstm.executeQuery();
			
			if(rs.next()) {
				return true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		return false;
	}

	/**
	 * @param code
	 * 对商品类型进行逻辑删除 发送update语句
	 */
	public void deleteArticleType(String code) {
		Connection con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			String sql = "update ec_article_type set delFlag = ? where code = ?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, "1");
			pstm.setString(2, code);
			
			// 进行查询
			pstm.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
	}
}
