package com.zx.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.zx.bean.User;
import com.zx.util.ConnectionFactory;
import com.zx.util.pager.PageModel;

public class UserDao {

	/**
	 * @param loginName
	 * @param passWord
	 * @return
	 */
	public User getUserByNameAndPass(String loginName, String passWord) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
			String sql = "select * from ec_user where login_name = ? and password = ?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, loginName);
			pstm.setString(2, passWord);
			
			//进行查询
			rs = pstm.executeQuery();
			
			//只拿一个
			if(rs.next()) {
				User u =new User();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setRole(rs.getInt("role"));
				u.setDisabled(rs.getString("disabled"));
				u.setEmail(rs.getString("email"));
				return u;
			}
			//将上面弄到的商品信息返回
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
		return null;
	}
	
	public User getUserById(Integer id) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
			String sql = "select * from ec_user where id = ?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setInt(1, id);
			
			//进行查询
			rs = pstm.executeQuery();
			
			//只拿一个
			if(rs.next()) {
				User u =new User();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setRole(rs.getInt("role"));
				u.setDisabled(rs.getString("disabled"));
				u.setEmail(rs.getString("email"));
				u.setPassword(rs.getString("password"));
				u.setPhone(rs.getString("phone"));
				return u;
			}
			//将上面弄到的商品信息返回
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
		return null;
	}

	
	
	
	/**
	 * @param user
	 * 保存用户
	 */
	public void saveUser(User user) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
//			String sql = "select * from ec_user where login_name = ? and password = ?";
			String sql = "insert into ec_user(login_name,password,name,sex,email,phone,address,create_date,active,role) values(?,?,?,?,?,?,?,?,?,?)";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, user.getLoginName());
			pstm.setString(2, user.getPassword());
			pstm.setString(3, user.getName());
			// System.out.println("Dao_user.getSex:"+user.getSex());
			pstm.setInt(4, user.getSex());
			pstm.setString(5, user.getEmail());
			pstm.setString(6, user.getPhone());
			pstm.setString(7, user.getAddress());
			pstm.setDate(8, new java.sql.Date(user.getCreateDate().getTime()));
			pstm.setString(9, user.getActive());
			
			pstm.setInt(10, user.getRole());
			//这下面不用把string类型的sql作为参数传到excuteUpdate()函数中去吗？
			//进行更新
			pstm.executeUpdate();
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
		
	}




	/**
	 * @param activeCode
	 * 用户信息激活
	 * 将该用户那一栏的disable从0改为1代表已激活可用 disabled是String类型
	 */
	public void activeUser(String activeCode) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
			String sql = "update ec_user set disabled = '1' where active = ?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, activeCode);
			
			//进行更新
			pstm.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
		
	}




	/**
	 * @param loginName
	 * @return
	 * 根据账号获取用户信息
	 */
	public boolean getUserByName(String loginName) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
			String sql = "select * from ec_user where login_name = ?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, loginName);
			
			//进行查询
			rs = pstm.executeQuery();
			
			//只拿一个
			if(rs.next()) {
				// System.out.println("用户存在");
				return true;
			}
			//将上面弄到的商品信息返回
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
		return false;
	}




	/**
	 * @return
	 * 获取所有的管理员 管理员的role(int)等于2 而超级管理员是3
	 */
	public List<User> getAllManageUser(PageModel pageModel) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
			String sql = "select * from ec_user where role != 3 limit ?,?";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setInt(1, pageModel.getStartNum());
			pstm.setInt(2, pageModel.getPageSize());
			
			//进行查询
			rs = pstm.executeQuery();
			
			List<User> users = new ArrayList<>();
			
			//只拿一个
			while(rs.next()) {
//				System.out.println("rs.getString(1)"+rs.getString(1));
				User u =new User();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setSex(rs.getInt("sex"));
				u.setAddress(rs.getString("address"));
				u.setPhone(rs.getString("phone"));
				u.setDisabled(rs.getString("disabled"));
				u.setEmail(rs.getString("email"));
				users.add(u);
			}
			//将上面弄到的商品信息返回
			return users;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}
		
		return null;
	}




	/**
	 * @param id
	 * @param disabled
	 * 激活或者冻结普通管理员账号
	 */
	public void activeUser(String id, String disabled) {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
			String sql = "update ec_user set disabled = ? where id = ? ";
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, disabled);
			pstm.setInt(2, Integer.valueOf(id));
			
			//进行更新(激活或者冻结操作)
			pstm.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		
	}




	/**
	 * @return
	 */
	public int getTotalNum() {
		Connection  con =null;
		PreparedStatement pstm=null;
		ResultSet rs = null;
		//while(resultset.next())组合
		
		try {
			//1.获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//2.定义sql语句	查所有的商品
			String sql = "select count(*) from ec_user where role != 3";
			//3.准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			
			//4.进行查询
			//查询的时候不用传入sql参数  有参数时pstm自己知道语句是什么  没有?不需要传入参数时可以传入sql
			rs = pstm.executeQuery();

			
			if(rs.next()) {
				return rs.getInt(1);	// get查询结构的第一个参数(count)就好
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(rs, pstm, con);
		}

		return 0;
	}

	/**
	 * @param user
	 */
	public void updateUser(User user) {
		Connection  con =null;
		PreparedStatement pstm=null;
//		ResultSet rs = null;
		//while(resultset.next())组合
		
		try {
			//获取连接
			con = ConnectionFactory.getCon();
			
			//准备需要发送的sql语句
			//定义sql语句	查所有的商品
			
			String sql = "update ec_user set name=?,password=?,email=?, phone=?,address=? where id = ?";
			
			//准备PreparedStatement对象 用于发送sql语句
			pstm = con.prepareStatement(sql);
			pstm.setString(1, user.getName());
			pstm.setString(2, user.getPassword());
			pstm.setString(3, user.getEmail());
			pstm.setString(4, user.getPhone());
			pstm.setString(5, user.getAddress());
			pstm.setInt(6, user.getId());
			
			// 执行sql语句
			pstm.executeUpdate();
			
			//将上面弄到的商品信息返回
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			//关闭连接
			ConnectionFactory.closeCon(null, pstm, con);
		}
	}
}
