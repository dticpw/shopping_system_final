package com.zx.service;

import java.util.Date;
import java.util.List;

import com.zx.bean.Article;
import com.zx.dao.ArticleDao;
import com.zx.util.pager.PageModel;

public class ArticleService {

	/**
	 * @return
	 * 获取所有的商品信息
	 */
	private ArticleDao articleDao = new ArticleDao();
	//导完ArticleDao去查商品信息

	public List<Article> getAllArticle(String typeCode, String keyword, PageModel pageModel, String flag) {
		// TODO Auto-generated method stub
		//这个百分号"%"是数据库查询语句中要用的
		typeCode= typeCode==null? "%":typeCode+"%";
		
		//给传进来的keyword加个判断
		//没有查询关键字就是查所有的数据 也就是"%%"的全匹配
		keyword = keyword == null ? "%%" : "%"+keyword+"%";
		
		// 查询总记录数
		int totalNum = articleDao.getTotalNum(typeCode, keyword, flag);
		// 将总记录数封装至pageModel对象中
		pageModel.setTotalNum(totalNum);
		
		List<Article> articles = articleDao.getAllArticle(typeCode, keyword, pageModel, flag);
		
		return articles;//把上面得到的数据返回出去
	}

	/**
	 * @param id
	 * @return
	 * 根据商品id获取商品信息
	 */
	public Article getArticleById(String id) {
		//化成整型就可以根据这个id调用articleDao进数据库取数据了
		return articleDao.getArticleById(Integer.valueOf(id));
	}

	/**
	 * 保存商品信息
	 * @param typeCode
	 * @param title
	 * @param supplier
	 * @param locality
	 * @param price
	 * @param storage
	 * @param description
	 * @param newFileName
	 */
	public void saveArticle(String typeCode, String title, String supplier, String locality, String price,
			String storage, String description, String newFileName) {
		Article article = new Article();
		article.setTitle(title);
		article.setImage(newFileName);
		article.setSupplier(supplier);
		article.setCreateDate(new Date());
		article.setLocality(locality);
		article.setDescription(description);
		article.setTypeCode(typeCode);
		article.setStorage(Integer.valueOf(storage));
		article.setSupplier(supplier);
		article.setPrice(Double.valueOf(price));
		
		articleDao.save(article);
	}

	/**
	 * @param typeCode
	 * @param title
	 * @param supplier
	 * @param locality
	 * @param price
	 * @param storage
	 * @param description
	 * @param image
	 * 更新商品信息
	 */
	public void updateArticle(String id, String typeCode, String title, String supplier, String locality, String price,
			String storage, String description, String image, String discount) {
		Article article = new Article();
		article.setId(Integer.valueOf(id));
		article.setTitle(title);
		article.setImage(image);
		article.setSupplier(supplier);
		article.setCreateDate(new Date());
		article.setLocality(locality);
		article.setDescription(description);
		article.setTypeCode(typeCode);
		article.setStorage(Integer.valueOf(storage));
		article.setSupplier(supplier);
		article.setPrice(Double.valueOf(price));
		article.setDiscount(Double.valueOf(discount));
		
		articleDao.update(article);
		
	}

	/**
	 * @param id
	 * @param disabled
	 */
	public void removeOrPutArticle(String id, String disabled) {
		articleDao.removeOrPutArticle(Integer.valueOf(id),disabled);
		
	}

}
