package com.zx.service;

import java.util.List;

import javax.management.RuntimeErrorException;

import com.zx.bean.ArticleType;
import com.zx.dao.ArticleTypeDao;
import com.zx.util.pager.PageModel;

public class ArticleTypeService {

	
	private ArticleTypeDao typeDao = new ArticleTypeDao();
	/**
	 * 获取所有一级类型
	 * @return
	 */
	public List<ArticleType> getAllFType() {
		// TODO Auto-generated method stub
		List<ArticleType> types = typeDao.getAllFType();
		return types;
	}
	
	/*
	 * @param typeCode
	 * @return
	 * 根据一级商品类型获取对应的二级商品类型	传入的是一级商品类型
	 */
	public List<ArticleType> getSecondTypesByCode(String typeCode) {
		// TODO //根据一级商品类型获取对应的二级商品类型	传入的是一级商品类型
		//查询语句为
		//SELECT * FROM ec_article_type WHERE CODE LIKE '0001%' AND LENGTH(CODE)=8;
		List<ArticleType> types = typeDao.getSecondTypesByCode(typeCode+"%");
		return types;
	}

	/**
	 * @return
	 */
	public List<ArticleType> getAllTypes(PageModel pageModel) {
		
		// 查询总记录数
		int totalNum = typeDao.getTotalNum();
		// 将总记录数封装至pageModel对象中
		pageModel.setTotalNum(totalNum);
		
		List<ArticleType> types = typeDao.getAllTypes(pageModel);
		
		return types;
	}

	/**
	 * @param parentCode
	 * @param name
	 * @param remark
	 * 添加商品类型
	 */
	public void addArticleType(String parentCode, String name, String remark) {
		
		ArticleType type = this.calcType(parentCode, name, remark);
		// 保存商品类型
		typeDao.saveType(type);
		
	}
	
	// 工具方法 新增商品类型
	public ArticleType calcType(String parentCode, String name, String remark) {
		ArticleType type = new ArticleType();
		type.setName(name);
		type.setRemark(remark);
		
		if(parentCode == null || parentCode.equals("")) {
			// 当前添加的是 一级商品类型
			/** 
			 * 获取最大的一级商品类型	
			 * 0015 -> 15(int) -> 16(int) -> 0016
			 * 0005 ->  5(int) ->  6(int) -> 0006
			 * String str = String.format("%04d", youNumber);
			 */ 
			String maxCode = typeDao.findMaxFcode();
			String fCode = String.format("%04d", Integer.valueOf(maxCode)+1);
			System.out.println(fCode);
			
			type.setCode(fCode);
		}else {
			/**
			 * 添加 二级商品类型
			 * 00010008 -> 00010009
			 */ 
			// 根据一级类型获取最大的二级类型
			System.out.println("parentCode:"+parentCode);
			String maxSecode = typeDao.findMaxScode(parentCode);	// "00010016"
			String sCode = "";
			if(maxSecode == null || maxSecode.equals("")) {
				sCode = parentCode+"0001";
			}else {
				System.out.println("maxSecode:"+maxSecode);
				sCode = String.format("%08d", Integer.valueOf(maxSecode)+1);
			}
			System.out.println("sCode:"+sCode);
			type.setCode(sCode);
		}
		return type;
	}
	

	/**
	 * @param code
	 * @return
	 * 根据商品类型的code获取整个商品类型
	 */
	public ArticleType getArticleType(String code) {
		ArticleType type = typeDao.getArticleType(code);
		return type;
	}

	/**
	 * @param name
	 * @param remark
	 * @param code
	 * 更新商品的name和remark
	 */
	public void updateType(String name, String remark, String code) {
		typeDao.updateType(name,remark,code);
		
	}

	/**
	 * @param name
	 * @param remark
	 * @param code
	 * @param parentCode
	 * 需要更换上级类型
	 * 1.将当前的商品类型挂在用户选择的上级类型下 进行添加操作
	 * 2.之前关联到该商品类型的商品类型code需要发生变化
	 * 3.删除之前的商品类型
	 */
	public void updateTypeWithUpperType(String name, String remark, String code, String parentCode) {
		// 计算好需要进行添加的 商品类型的数据
		ArticleType type = calcType(parentCode, name, remark);
		
		typeDao.updateTypeWithUpperType(type,code,name,remark);
		
	}

	/**
	 * @param code
	 * 删除商品类型
	 * 如果一个类型中的商品全部都下架了 那么允许删除这个类型
	 */
	public void deleteArticleType(String code) {
		// 判断商品类型下是否还有未下架的商品 1有 不能删 0无 能删
		boolean flag = typeDao.findArticleByCode(code);
		if(flag) {
			// 该商品类型下还存在上架的商品信息
			throw new RuntimeException("删除失败：该商品类型下仍存在上架状态的商品！");
		}
		// 没有return即flag=0可以删
		typeDao.deleteArticleType(code);
		
	}

	/**
	 * @return
	 * 获取所有的商品信息
	 */
//	private ArticleDao articleDao = new ArticleDao();
//	//导完ArticleDao去查商品信息
//
//	public List<Article> getAllArticle() {
//		// TODO Auto-generated method stub
//		List<Article> articles = articleDao.getAllArticle();
//		
//		return articles;//把上面得到的数据返回出去
//	}

}
