package com.zx.controller.front;

import java.io.IOException;
//import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zx.util.ConstantUtil;

//import com.zx.bean.Article;
//import com.zx.bean.ArticleType;
//import com.zx.service.ArticleService;
//import com.zx.service.ArticleTypeService;

/**
 * 用户退出
 */
@WebServlet("/logout.action")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//将session中的用户信息清除
		req.getSession().removeAttribute(ConstantUtil.SESSION_USER);
		
		//跳转到首页 
		req.getRequestDispatcher("/index.jsp").forward(req, resp); 

	}

	

}
