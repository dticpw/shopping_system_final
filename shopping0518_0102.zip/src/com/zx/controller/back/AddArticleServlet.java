package com.zx.controller.back;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.zx.bean.Article;
import com.zx.bean.ArticleType;
import com.zx.service.ArticleService;
import com.zx.service.ArticleTypeService;
import com.zx.util.pager.PageModel;

/**
 * 添加商品信息
 * 当需要进行文件上传的时候，后台Servlet必须加上 @MultipartConfig 不然文件上传不了的
 */
@MultipartConfig
@WebServlet("/addArticle.do")
public class AddArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * 下面该去查询数据库
     * 加一些service方法
     * 调用service包中的ArticleService类方法
     */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		// 取商品图片
		Part part = req.getPart("pic");
		// 获取文件的原始名称
		String fileName = part.getSubmittedFileName();
		// 通过UUID生成新的文件名  拼上从原始文件名上截取下来的后缀
		String newFileName = UUID.randomUUID().toString()+fileName.substring(fileName.lastIndexOf("."));
		System.out.println("新的文件名："+newFileName);
		//指定要上传的路径
		String path = req.getServletContext().getRealPath("/resources/image/article");
		// 将文件写到路径下
		part.write(path+File.separator+newFileName);
		System.out.println("文件上传的路径："+path+File.separator+newFileName);
		
		
		// 获取商品 二级类型 标题 供应商 出产地 价格 库存 描述信息
		String typeCode = req.getParameter("code");	// 页面那边叫code
		String title = req.getParameter("title");
		String supplier = req.getParameter("supplier");
		String locality = req.getParameter("locality");
		String price = req.getParameter("price");
		String storage = req.getParameter("storage");
		String description = req.getParameter("description");
		
		ArticleService as = new ArticleService();
		// 保存商品信息
		as.saveArticle(typeCode,title,supplier,locality,price,storage,description,newFileName);
		

		
		// 重定向至后台首页
		resp.sendRedirect(req.getContextPath()+"/mindex.do");
		//WEB-INF下面的view下面的front下面的articleIndex.jsp	//右键copy qualified name
		//req:request resp:response
				
		//服务层得去调用dao层
	}

	

}
