package com.zx.controller.back;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.zx.bean.Article;
import com.zx.bean.ArticleType;
import com.zx.bean.User;
import com.zx.service.ArticleService;
import com.zx.service.ArticleTypeService;
import com.zx.service.UserService;
import com.zx.util.pager.PageModel;

/**
 * 用户管理
 */
@MultipartConfig
@WebServlet("/userList.do")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * 下面该去查询数据库
     * 加一些service方法
     * 调用service包中的ArticleService类方法
     */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 查询数据库 返回所有用户信息
		UserService us = new UserService();
		// 加入分页
		PageModel pageModel = new PageModel();
		// 获取页码
		String pageIndex = req.getParameter("pageIndex");
		if(pageIndex != null  && !pageIndex.equals("")) {
			pageModel.setPageIndex(Integer.valueOf(pageIndex));
		}
		req.setAttribute("pageModel", pageModel);
		
		List<User> users = us.getAllManageUser(pageModel);
		req.setAttribute("users", users);
		req.setAttribute("highlight", "userty");
		
		req.getRequestDispatcher("/WEB-INF/view/back/user/list.jsp").forward(req, resp);
	}

	

}
