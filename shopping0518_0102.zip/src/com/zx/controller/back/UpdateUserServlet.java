package com.zx.controller.back;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.zx.bean.Article;
import com.zx.bean.ArticleType;
import com.zx.service.ArticleService;
import com.zx.service.ArticleTypeService;
import com.zx.service.UserService;
import com.zx.util.pager.PageModel;

/**
 * 添加商品信息
 * 当需要进行文件上传的时候，后台Servlet必须加上 @MultipartConfig 不然文件上传不了的
 */
@MultipartConfig
@WebServlet("/userUpdate.do")
public class UpdateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    // doGet展示商品信息
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.getRequestDispatcher("/WEB-INF/view/back/user/updateSelf.jsp").forward(req, resp);
	}

	// doPost修改商品信息
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 获取用户id
		String id = req.getParameter("id");
		String loginName = req.getParameter("loginName");
		System.out.println("userId:"+id);
		System.out.println("loginName:"+loginName);
		
		String name = req.getParameter("name");
		String password = req.getParameter("password");
//		String okPassword = req.getParameter("okPassword");
		String sex = req.getParameter("sex");
		String phone = req.getParameter("phone");
		String address = req.getParameter("address");
		String email = req.getParameter("email");
		System.out.println("info:"+id+loginName+name+password+sex+phone+address+email);
		
		try {
			UserService us = new UserService();
			us.updateUser(id,name,password,email,phone,address);
			req.setAttribute("message", "个人信息修改成功！");
		} catch (Exception e) {
			// TODO: handle exception
			req.setAttribute("message", e.getMessage());
		}
		
		
		
//		UserService us = new UserService();
		// 更新商品信息
//		as.updateArticle(id,typeCode,title,supplier,locality,price,storage,description,image,discount);
//		us.updateUser(id,loginName,name,password,okPassword,sex,phone,address,email);

		
		// 重定向至后台首页
		req.getRequestDispatcher("/WEB-INF/view/back/user/updateSelf.jsp").forward(req, resp);
	}
    
	

}
