package com.zx.controller.back;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.zx.bean.Article;
import com.zx.bean.ArticleType;
import com.zx.service.ArticleService;
import com.zx.service.ArticleTypeService;
import com.zx.util.pager.PageModel;

/**
 * 处理商品类型列表页面数据
 */
@MultipartConfig
@WebServlet("/articleTypeList.do")
public class ArticleTypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArticleTypeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * 下面该去查询数据库
     * 加一些service方法
     * 调用service包中的ArticleService类方法
     */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ArticleTypeService ats = new ArticleTypeService();
		
		// 加入分页
		PageModel pageModel = new PageModel();
		// 获取页码
		String pageIndex = req.getParameter("pageIndex");
		if(pageIndex != null  && !pageIndex.equals("")) {
			pageModel.setPageIndex(Integer.valueOf(pageIndex));
		}
		req.setAttribute("pageModel", pageModel);
		
		
		// 获取所有的商品类型
		List<ArticleType> types = ats.getAllTypes(pageModel);
		req.setAttribute("types", types);
		
		req.setAttribute("highlight", "typety");
		

		
//		// 重定向至后台首页
//		resp.sendRedirect(req.getContextPath()+"/mindex.do");
		// 跳转至商品类型列表页面
		req.getRequestDispatcher("/WEB-INF/view/back/articleType/list.jsp").forward(req, resp);
		
	}

	

}
