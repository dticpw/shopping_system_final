package com.zx.controller.back;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.zx.bean.Article;
import com.zx.bean.ArticleType;
import com.zx.service.ArticleService;
import com.zx.service.ArticleTypeService;
import com.zx.util.pager.PageModel;

/**
 * 添加商品类型
 * back/articleType/list.jsp这里直接是doGet方法 跳转到view.jsp
 * 	/addOrUpdateArticleType.do那个+号触发的
 * view.jsp		
 * 	添加商品类型/addOrUpdateArticleType.do
 * 	修改商品类型/addOrUpdateArticleType.do?method='update'
 */
@WebServlet("/addOrUpdateArticleType.do")
public class AddOrUpdateArticleTypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddOrUpdateArticleTypeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    
    // 这个doGet方法只是打开list.jsp时过来拿一下库中的信息展示到/back/articleType/list.jsp中去
    // addOrUpdateArticleType.do?code=${t.code}
    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	ArticleTypeService ats = new ArticleTypeService();
    	
    	String code = req.getParameter("code");
    	if(code!=null && !code.equals("")) {
    		// 有code 进行更新 根据商品类型的code获取商品类型
    		ArticleType type = ats.getArticleType(code);
    		req.setAttribute("articleType", type);
    	}
    	
		List<ArticleType> types = ats.getAllFType();
		req.setAttribute("types", types);

		// 请求转发的时候 url不会发生变化
		req.getRequestDispatcher("/WEB-INF/view/back/articleType/view.jsp").forward(req, resp);
	}


    // doPost方法主要是 view.jsp中的表单的请求 有添加商品类型 和 修改商品类型 两种
    // addOrUpdateArticleType.do?code=${t.code}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ArticleTypeService ats = new ArticleTypeService();
		// 这些做前面的post的form表单	提交parentCode name remark
		String parentCode = req.getParameter("parentCode");
		String name = req.getParameter("name");
		String remark = req.getParameter("remark");
		
		// 获取商品类型的code
		String code = req.getParameter("code");
		if(code!=null && !code.equals("")) {
			/**
			 * 进行更新操作
			 * 判断用户有没有更换上级类型
			 */
			// 获取历史上级类型 和当前选择的上级类型进行比较
			String oldPcode = code.substring(0,code.length()-4);
			if(oldPcode.equals(parentCode)) {
				// 并未改变上级类型
				ats.updateType(name,remark,code);
			}else {
				// 需要更换上级类型
//				System.out.println("=====更换上级类型=====");
				ats.updateTypeWithUpperType(name,remark,code,parentCode);
				
			}
		}else {
			// 进行添加操作
			ats.addArticleType(parentCode,name,remark);
		}
		
		
		
		// 重定向至后台首页
		resp.sendRedirect(req.getContextPath()+"/articleTypeList.do");
		
	}


}
