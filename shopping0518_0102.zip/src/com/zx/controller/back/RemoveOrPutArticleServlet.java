package com.zx.controller.back;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.zx.bean.Article;
import com.zx.bean.ArticleType;
import com.zx.service.ArticleService;
import com.zx.service.ArticleTypeService;
import com.zx.util.pager.PageModel;

/**
 * 后台对商品进行上架与下架处理
 */
@WebServlet("/removeOrPutArticle.do")
public class RemoveOrPutArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveOrPutArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * 下面该去查询数据库
     * 加一些service方法
     * 调用service包中的ArticleService类方法
     */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArticleService as = new ArticleService();
		
		// 获取商品id
		// <c:url value="/removeOrPutArticle.do?id=${a.id}&disabled=1"/>">下架</a>
		// <c:url value="/removeOrPutArticle.do?id=${a.id}&disabled=0"/>">上架</a>
		String id = req.getParameter("id");
		
		// 获取上架或下架标记disabled
		String disabled = req.getParameter("disabled");
		
		as.removeOrPutArticle(id,disabled);
		
		// 重定向至后台首页
		resp.sendRedirect(req.getContextPath()+"/mindex.do");
		
	}

	

}
