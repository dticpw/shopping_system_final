package com.zx.controller.back;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.zx.bean.Article;
import com.zx.bean.ArticleType;
import com.zx.service.ArticleService;
import com.zx.service.ArticleTypeService;
import com.zx.util.pager.PageModel;

/**
 * 添加商品信息
 * 当需要进行文件上传的时候，后台Servlet必须加上 @MultipartConfig 不然文件上传不了的
 */
@MultipartConfig
@WebServlet("/articleUpdate.do")
public class UpdateArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    // doGet展示商品信息
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArticleService as = new ArticleService();
		
		ArticleTypeService ats = new ArticleTypeService();
		
		//获取商品的id
		String id = req.getParameter("id");
		Article article = as.getArticleById(id);
		
		// 获取所有的一级商品类型
		List<ArticleType> types = ats.getAllFType();
		req.setAttribute("types", types);
		
		req.setAttribute("article", article);
		req.getRequestDispatcher("/WEB-INF/view/back/article/updateArticle.jsp").forward(req, resp);
	}

	// doPost修改商品信息
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 获取商品id
		String id = req.getParameter("id");
		
		// 获取商品原始封面名称/地址
		String image = req.getParameter("image");
		
		// 取商品图片
		Part part = req.getPart("pic");
		System.out.println("part:"+part);
		// 获取文件的原始名称
		String fileName = part.getSubmittedFileName();
		if(fileName!=null&& !fileName.equals("")) {
			// 通过UUID生成新的文件名  拼上从原始文件名上截取下来的后缀
			image = UUID.randomUUID().toString()+fileName.substring(fileName.lastIndexOf("."));
			System.out.println("新的文件名："+image);
			//指定要上传的路径
			String path = req.getServletContext().getRealPath("/resources/image/article");
			// 将文件写到路径下
			part.write(path+File.separator+image);
			System.out.println("文件上传的路径："+path+File.separator+image);
		}
		
		// 获取商品 二级类型 标题 供应商 出产地 价格 库存 描述信息 折扣
		String typeCode = req.getParameter("code");	// 页面那边叫code
		String title = req.getParameter("title");
		String supplier = req.getParameter("supplier");
		String locality = req.getParameter("locality");
		String price = req.getParameter("price");
		String storage = req.getParameter("storage");
		String description = req.getParameter("description");
		String discount = req.getParameter("discount");
		
		ArticleService as = new ArticleService();
		// 更新商品信息
		as.updateArticle(id,typeCode,title,supplier,locality,price,storage,description,image,discount);
		

		
		// 重定向至后台首页
		resp.sendRedirect(req.getContextPath()+"/mindex.do");
	}
    
	

}
